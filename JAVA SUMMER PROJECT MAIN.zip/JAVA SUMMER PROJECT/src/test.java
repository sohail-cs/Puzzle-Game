import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import PICTUREPUZZLE.PICTUREPUZZLEBOARD;

class test {

	@Test
	void test() {
		PICTUREPUZZLEBOARD board = new PICTUREPUZZLEBOARD();
	}

}
